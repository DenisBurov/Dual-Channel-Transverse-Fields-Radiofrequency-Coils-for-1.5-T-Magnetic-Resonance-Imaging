Hello!

To use the script, download all three .m files, add them to the same directory and run the one with the longest name.
If you wish to make changes to any of the parameters, make sure you use standart units (meters). All the relevant parameters are commented in the code.
To switch between 1.Lateral shift and 2. Side decrease you should comment the section you do not need. 
The code is information from the book Paul, C. R. (2009). Inductance: Loop and Partial. Wiley. Retrieved from https://www.wiley.com/en-us/Inductance%3A+Loop+and+Partial-p-9780470461884

If you intend to use this code in your research, PLEASE CITE OUR ARTICLE.

In case of any questions about the code, don't hesitate to contact me at denis.burov@proton.me

Best regards,
Denis Burov
